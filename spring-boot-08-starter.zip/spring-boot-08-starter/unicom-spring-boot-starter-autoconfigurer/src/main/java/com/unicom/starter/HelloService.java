package com.unicom.starter;

import lombok.Data;

/**
 * @Copyright: Unicom (Zhejiang) Industrial Internet Co., Ltd.    2019 <br/>
 * @Desc: <br/>
 * @ProjectName: spring-boot-08-starter <br/>
 * @Date: 2019/10/18 15:42 <br/>
 * @Author: yangjiabin
 */
@Data
public class HelloService {

    HelloProperties helloProperties;

    public String sayHelloUnicom(String name){
        return helloProperties.getPrefix()
                + "--" + name + "--"
                + helloProperties.getSuffix();
    }

}
