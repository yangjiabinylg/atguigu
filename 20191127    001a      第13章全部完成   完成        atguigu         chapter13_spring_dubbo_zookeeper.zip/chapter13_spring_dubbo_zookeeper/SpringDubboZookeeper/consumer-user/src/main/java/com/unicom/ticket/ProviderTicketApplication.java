package com.unicom.ticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *   1.将服务提供者注册到注册中心
 *        1.引入dubbo和zkclinet的相关依赖 (pom文件)
 *        2.配置dubbo的扫描包和注册中心的地址（yml文件）
 *        3.使用@Service来发布服务
 *
 */
@SpringBootApplication
public class ProviderTicketApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProviderTicketApplication.class, args);
    }

}
