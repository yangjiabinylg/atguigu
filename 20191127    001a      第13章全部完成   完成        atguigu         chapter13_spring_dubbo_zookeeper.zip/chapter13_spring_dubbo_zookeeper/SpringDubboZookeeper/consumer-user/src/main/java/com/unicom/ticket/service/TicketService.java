package com.unicom.ticket.service;

/**
 * @Copyright: Unicom (Zhejiang) Industrial Internet Co., Ltd.    2019 <br/>
 * @Desc: <br/>
 * @ProjectName: SpringDubboZookeeper <br/>
 * @Date: 2019/11/26 19:30 <br/>
 * @Author: yangjiabin
 */
public interface TicketService {

     String getTicket();

}
/**
      这个接口和和提供者的  Service是一样的。  直接复制过来
      全路径 包括包也要复制过来

 */