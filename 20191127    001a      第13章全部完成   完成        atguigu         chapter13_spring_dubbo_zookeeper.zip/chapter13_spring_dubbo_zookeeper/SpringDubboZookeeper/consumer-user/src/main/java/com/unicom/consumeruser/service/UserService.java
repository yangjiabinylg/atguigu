package com.unicom.consumeruser.service;

import com.alibaba.dubbo.config.annotation.Reference;
import com.unicom.ticket.service.TicketService;
import org.springframework.stereotype.Service;

/**
 * @Copyright: Unicom (Zhejiang) Industrial Internet Co., Ltd.    2019 <br/>
 * @Desc: <br/>
 * @ProjectName: SpringDubboZookeeper <br/>
 * @Date: 2019/11/26 19:40 <br/>
 * @Author: yangjiabin
 */



//这个是spring的service不是阿里巴巴的
@Service
public class UserService {

    /**
     *    这个service远程调用    provider-ticket的service
     */

    //阿里巴巴的   远程引用   匹配是全类名进行匹配
    @Reference
    TicketService ticketService;

    public void hello(){
        String ticket = ticketService.getTicket();
        System.out.println("买了票"+ticket);
    }

}
