package com.unicom.ticket.service;

import com.alibaba.dubbo.config.annotation.Service;
import org.springframework.stereotype.Component;
import sun.security.krb5.internal.TicketFlags;

/**
 * @Copyright: Unicom (Zhejiang) Industrial Internet Co., Ltd.    2019 <br/>
 * @Desc: <br/>
 * @ProjectName: SpringDubboZookeeper <br/>
 * @Date: 2019/11/26 19:32 <br/>
 * @Author: yangjiabin
 */


//让spring容器来管理这个service
@Component
//这个是阿里巴巴的service
@Service//将服务发布出去   发布的时候是全类名发布  包括包
public class TicketServiceImpl implements TicketService {

    @Override
    public String getTicket() {
        //返回电影
        return "《厉害了！！！》";
    }


}
