package com.unicom.ticket.service;

/**
 * @Copyright: Unicom (Zhejiang) Industrial Internet Co., Ltd.    2019 <br/>
 * @Desc: <br/>
 * @ProjectName: SpringDubboZookeeper <br/>
 * @Date: 2019/11/26 19:30 <br/>
 * @Author: yangjiabin
 */
public interface TicketService {

     String getTicket();

}
