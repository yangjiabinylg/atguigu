package com.unicom.consumeruser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * @Copyright: Unicom (Zhejiang) Industrial Internet Co., Ltd.    2019 <br/>
 * @Desc: <br/>
 * @ProjectName: chapter13_spring_cloud <br/>
 * @Date: 2019/11/27 10:49 <br/>
 * @Author: yangjiabin
 */
@RestController
public class UserController {

    @Autowired
    RestTemplate restTemplate;

    @GetMapping("/buy")
    public String buyTicket(String name){
        //PROVIDER-TICKET  PROVIDER-TICKET
        //restTemplate.getForObject("http://localhost:8002/ticket",String.class);
        String fileName = restTemplate.getForObject("http://PROVIDER-TICKET/ticket", String.class);
        return name+"购买了"+fileName;
    }


}
