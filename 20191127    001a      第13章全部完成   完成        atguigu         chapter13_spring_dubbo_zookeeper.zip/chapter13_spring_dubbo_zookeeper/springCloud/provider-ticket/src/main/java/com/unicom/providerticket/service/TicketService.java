package com.unicom.providerticket.service;

import org.springframework.stereotype.Service;

/**
 * @Copyright: Unicom (Zhejiang) Industrial Internet Co., Ltd.    2019 <br/>
 * @Desc: <br/>
 * @ProjectName: chapter13_spring_cloud <br/>
 * @Date: 2019/11/27 10:09 <br/>
 * @Author: yangjiabin
 */

@Service
public class TicketService {

    public String getTicket(){
        return "《厉害了啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊！！！！！》";
    }



}
