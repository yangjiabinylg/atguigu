package com.unicom.providerticket.controller;

import com.unicom.providerticket.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Copyright: Unicom (Zhejiang) Industrial Internet Co., Ltd.    2019 <br/>
 * @Desc: <br/>
 * @ProjectName: chapter13_spring_cloud <br/>
 * @Date: 2019/11/27 10:11 <br/>
 * @Author: yangjiabin
 */
@RestController
public class TicketController {


    @Autowired
    TicketService ticketService;


    @GetMapping("/ticket")
    public String getTicket(){
        System.out.println("8002");
        return ticketService.getTicket();
    }
    /**
     *     为了别人能够访问提供者，新建一个controller，
     *     因为spring cloud再整合微服务的时候，是通过轻量级http服务
     *     是通过http的方式将接口暴露出来
     */



}
